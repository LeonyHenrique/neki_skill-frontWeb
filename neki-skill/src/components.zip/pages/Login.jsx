import React, {useState} from "react";
import styles from './Login.module.css';
import { loginUser } from "../service/usuario/userService";


const Login =()=>{
    const [loginInput, setLoginInput]= useState("");
    const [senha, setSenha] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [rememberMe, setRememberMe] = useState(false);

    const handleLogin = async ()=>{
      console.log(loginInput,senha)
        try{
            const response = loginUser(loginInput, senha);
            console.log(response)
            if (response.status === 200) {
                if (rememberMe) {
                  localStorage.setItem('user', JSON.stringify({ login: loginInput, senha }));
        }
        window.location.href = '/home';
    }else{
      alert('Login ou senha incorretos.');
        
        }
        }catch (error) {
      console.error('Erro ao fazer login:', error);
    }
};
return (
    <div className={styles.loginContainer}>
        <h2>login</h2>
        <input
        type="text"
        placeholder="login"
        value={loginInput}
        onChange={(e) => setLoginInput(e.target.value)}
        className={styles.inputF}
        />
          <div className={styles.passwordContainer}>
        <input
        type={showPassword ? 'text' : 'password'}
        placeholder="senha"
        value={senha}
        onChange={(e) => setSenha(e.target.value)}
        className={styles.checkbox}
        />
            <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className={styles.showPasswordButton}
        >
          {showPassword ? 'Esconder' : 'Mostrar'}
        </button>
      </div>
        <label className={styles.checkboxLabel}>
        <input
          type="checkbox"
          checked={rememberMe}
          onChange={(e) => setRememberMe(e.target.checked)}
          className={styles.checkbox}
        />
        Gravar as senha
        </label>
           <button onClick={handleLogin} className={styles.button}>Entrar</button>
           <button onClick={() => {window.location.href = '/registro'}} className = {styles.button}>Cadastrar-se</button>
    </div>
);
};
export default Login;
