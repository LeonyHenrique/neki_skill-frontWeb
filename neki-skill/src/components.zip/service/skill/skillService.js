import { api } from "../api/api";

export const getSkills = async (usuarioId) => {
    try {
      const response = await api.get(`/skills/${usuarioId}`);
      return response.data;
    } catch (error) {
      console.error("Erro ao obter skills:", error);
      throw error;
    }
};

    export const addSkill = async (skill) => {
        try {
          const response = await api.post('/skills', skill);
          return response.data;
        } catch (error) {
          console.error("Erro ao adicionar skill:", error);
          throw error;
        }
    };
    export const updateSkill = async (id, skill) => {
        try {
          const response = await api.put(`/skills/${id}`, skill);
          return response.data;
        } catch (error) {
          console.error("Erro ao atualizar skill:", error);
          throw error;
        }
      };
      export const deleteSkill = async (id) => {
        try {
          await api.delete(`/skills/${id}`);
        } catch (error) {
          console.error("Erro ao excluir skill:", error);
          throw error;
        }
      };