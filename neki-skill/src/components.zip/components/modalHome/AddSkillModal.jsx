import React from "react";
import Modal from "react-modal";
import styles from "./AddSkillModal.module.css";

Modal.setAppElement('#root');

const AddSkillModal = ({isOpen, onRequestClose, novaSkill, setNovaSkill, handleAdicionarSkill}) =>{
    return(
        <Modal
        isOpen={isOpen}
        onRequestClose={onRequestClose}
        className={styles.modal}
        overlayClassName={styles.overlay}
        >
            <h2>Adicionar Nova Skill</h2>
            <input
            type="text"
            placeholder="Nome"
            value={novaSkill.nome}
            onChange={(e) => setNovaSkill({...novaSkill, nome: e.target.value})}
            className={styles.inputField}
            />
            <input
            type="text"
            placeholder="Nivel"
            value={novaSkill.nivel}
            onChange={(e) => setNovaSkill({...novaSkill, nivel: e.target.value})}
            className={styles.inputField}
            />
            <input
            type="text"
            placeholder="Descrição"
            value={novaSkill.descricao}
            onChange={(e) => setNovaSkill({...novaSkill, descricao: e.target.value})}
            className={styles.inputField}
            />
            <button className={styles.button} onClick={handleAdicionarSkill}>Adicionar</button>
            <button onClick={onRequestClose} className={styles.button}>Cancelar</button>
        </Modal>
    );
};
export default AddSkillModal;