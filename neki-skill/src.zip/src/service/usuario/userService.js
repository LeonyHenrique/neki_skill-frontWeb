import { api } from "../api/api";

export const registerUser = async (login, senha) => {
  try {
      const response = await api.post('/usuarios/register', { login, senha });
      return response;
  } catch (error) {
      console.error("Erro ao registrar usuário:", error);
      throw error;
  }
};

export const loginUser = async (login, senha) => {
  try {
      const response = await api.post('/usuarios/login', { login, senha });
      return response;
  } catch (error) {
      console.error("Erro ao fazer login:", error);
      throw error;
  }
  };
