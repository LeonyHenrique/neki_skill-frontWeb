import React, { useEffect, useState } from "react";
import styles from "./Home.module.css";
import AddSkillModal from "../components/modalHome/AddSkillModal";
import { getSkills, addSkill, updateSkill, deleteSkill } from "../service/skill/skillService";

const Home = () =>{
 const [skills, setSkills] = useState([]);
 const [novaSkill, setNovaSkill] = useState ({nome:"", nivel: "", descricao:""});
 const [editingSkillId, setEditingSkillId] = useState(null);
 const [editedNivel, setEditedNivel] = useState('');
 const [modalIsOpen, setModalIsOpen] = useState(false);

 useEffect(() => {
    const fetchSkills = async () =>{
        try{
            const idUsuario = 1;
            const response = await getSkills(idUsuario);
            setSkills(response);
            }catch(error){
                console.log("erro ao obter skills: ",error);
        }
    };
    fetchSkills();
    }, []);

    const handleAdicionarSkill = async ()=>{
        try{
            const response = await addSkill(novaSkill);
            setSkills([...skills, response]);
            setNovaSkill({ nome: '', nivel: '', descricao: '' });
            setModalIsOpen(false);
    } catch (error) {
        console.log("erro ao adicionar skill: ", error);
        }
        };
        const handleExcluirSkill = async (idSkill) => {
            try {
                await deleteSkill (idSkill);
                setSkills(skills.filter(skill => skill.id !== idSkill));
                } catch (error) {
                    console.log("erro ao excluir skill: ", error);
                    }
                    };
                    const handleEditarSkill = async (skill) => {
                        try{
                        const skillAtualizada = { ...skills.find(skill => skill.id === idSkill), nivel: editedNivel };
                        const response = await updateSkill(idSkill, skillAtualizada);
                        setSkills(skills.map(skill => (skill.id === idSkill ? response : skill)));
                        setEditingSkillId(null);
                        }catch(error){
                            console.log("erro ao editar skill: ", error);
                        }                
                        };
                        const  handleLogout = () => {
                            localStorage.removeItem('user');
                            window.location.href = '/';
                            };

    return(
        <div className={styles.homecontainer}>
            <h2>minhas skills</h2>
            <div className={styles.logout}>
            <button onClick={handleLogout} className={styles.logoutButton}>Logout</button>
            </div>
            <div className={styles.skillList}>
                {skills.map(skill => (
                    <div key={skill.id} className={styles.skillCard}>
                        <h3>{skill.nome}</h3>
                        <p>
              Nível: 
              {editingSkillId === skill.id ? (
                <input
                  type="text"
                  value={editedNivel}
                  onChange={(e) => setEditedNivel(e.target.value)}
                  className={styles.inputField}
                />
              ) : (
                skill.nivel
              )}
            </p>
                        <p>{skill.descricao}</p>
                        {editingSkillId === skill.id ? (
              <button onClick={() => handleAtualizarSkill(skill.id)} className={styles.button}>
                Salvar
              </button>
            ) : (
              <button onClick={() => {
                setEditingSkillId(skill.id);
                setEditedNivel(skill.nivel);
              }} className={styles.button}>
                Editar
              </button>
            )}
                        <button onClick={() => handleExcluirSkill(skill.id)} className={styles.button}>excluir</button>
        </div>
    ))}
    </div>
    <div className={styles.addSkillForm}>
        <h3>adicionar skill</h3>
         </div>
         <button onClick= {() => setModalIsOpen(true)} className={styles.button}>Adicionar Skill</button>
         <AddSkillModal
        isOpen={modalIsOpen}
        onRequestClose={() => setModalIsOpen(false)}
        novaSkill={novaSkill}
        setNovaSkill={setNovaSkill}
        handleAdicionarSkill={handleAdicionarSkill}
      />
         </div>
    );
};
export default Home;