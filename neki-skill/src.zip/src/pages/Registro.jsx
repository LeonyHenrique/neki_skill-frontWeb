import React, { useState }  from "react";
import styles from './Registro.module.css';
import { registerUser } from "../service/usuario/userService";

const Registro = ()=>{
    const [login , setLogin] = useState('');
    const [senha , setSenha] = useState('');
    const [confirmarSenha, setConfirmarSenha] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);

    const handleRegistro = async () => {
        if (senha !== confirmarSenha){
            alert("as senhas estão diferentes");
            return;
        }
        try{
            const response = await registerUser(login, senha);
            console.log(response)
            if (response.status === 200){
                alert("usuário criado com sucesso");
                window.location.href = '/';
            } else {
                alert("usuário não criado");
            }
        } catch(error){
            console.error("erro ao fazer cadastro", error);
        }
    };
    return (
        <div className={styles.registroContainer}>
            <h2>Cadastro</h2>
            <input
            type="text"
            placeholder="Login"
            value={login}
            onChange={(e) => setLogin(e.target.value)}
            className={styles.inputField}
            />
            <div className={styles.passwordContainer}>
            <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Senha"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            className={styles.inputField}
            />
             <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className={styles.showPasswordButton}
        >
          {showPassword ? 'Esconder' : 'Mostrar'}
        </button>
      </div>
      <div className={styles.passwordContainer}>
            <input
            type={showConfirmPassword ? 'text' : 'password'}
            placeholder="Confirmar senha"
            value={confirmarSenha}
            onChange={(e) => setConfirmarSenha(e.target.value)}
            className={styles.inputField}
            />
             <button
          type="button"
          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
          className={styles.showPasswordButton}
        >
          {showConfirmPassword ? 'Esconder' : 'Mostrar'}
        </button>
      </div>
            <button onClick={handleRegistro} className={styles.button}>Cadastrar</button>
        </div>
    );
};
export default Registro;